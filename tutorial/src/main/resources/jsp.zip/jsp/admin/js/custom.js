$(document).ready(function(){
	viewQuestionList();
	getAllSubject();
	setUpAddNewQuestionPage();
	$('#error_message').css('display', 'none');
	$('#success_message').css('display', 'none');
	
	
	$('.is-changed').keypress(function(){
		$('#error_message_id').hide();
		$('#success_message_id').hide();
	});
	// Appending options new-question
//	$('#option_a').blur(function(){
//		var optionA = $('#option_a').val();
//		if ($('#A_option').val()) {
//			$('#A_option').val(optionA);
//			$('#A_option').text(optionA);
//		}else if(optionA){
//			$('#correct_ans_id').append('<option id="A_option" value="'+optionA+'">'+optionA+'</option>');
//		}
//	});
//	$('#option_b').blur(function(){
//		var optionB = $('#option_b').val();
//		if ($('#B_option').val()) {
//			$('#B_option').val(optionB);
//			$('#B_option').text(optionB);
//		}else if(optionB){
//			$('#correct_ans_id').append('<option id="B_option" value="'+optionB+'">'+optionB+'</option>');
//		}
//	});
//	$('#option_c').blur(function(){
//		var optionC = $('#option_c').val();
//		if ($('#C_option').val()) {
//			$('#C_option').val(optionC);
//			$('#C_option').text(optionC);
//		}else if(optionC){
//			$('#correct_ans_id').append('<option id="C_option" value="'+optionC+'">'+optionC+'</option>');
//		}
//	});
//	$('#option_d').blur(function(){
//		var optionD = $('#option_d').val();
//		if ($('#D_option').val()) {
//			$('#D_option').val(optionD);
//			$('#D_option').text(optionD);
//		}else if(optionD){
//			$('#correct_ans_id').append('<option id="D_option" value="'+optionD+'">'+optionD+'</option>');
//		}
//	});
//	
	$('#add_sub_btn').click(function(){
		//alert("clicked");
		 $('#add_subject_form').submit();
	});
	
	$('#add_question_btn_id').click(function(){
		//alert("clicked");
		 $('#add_question_form_id').submit();
	});
	
	$('#sub_name').keypress(function(){
		 $('#error_message').css('display', 'none');
	 		$('#success_message').css('display', 'none');
	});
	
	
	var add_subject_form = $('#add_subject_form');
	add_subject_form.submit(function () {
		var sub_name = $('#sub_name').val();
		if(sub_name.trim().length==0){
			 $('#error_message').css('display', 'block');
		 		$('#success_message').css('display', 'none');
		     	$('#error_message').text('please provide subject name');
			return false;
		}else{
			var getUrl = window.location;
			var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
			 $.ajax({
			     type: add_subject_form.attr('method'),
			     url: baseUrl+'/AddSubjectController',
			     data: add_subject_form.serialize(),
			     success: function (data) {
			     if(data.operationCode==1){
			    	// alert('subject successfully saved!');
			    		$('#error_message').css('display', 'none');
			    		$('#success_message').css('display', 'block');
			    	$('#success_message').text('subject successfully saved!');
			     }else{
			    	// alert('subject does not saved!');
			    	 $('#error_message').css('display', 'block');
			 		$('#success_message').css('display', 'none');
			     	$('#error_message').text('subject does not saved!');
			     }
			     
			    // $('#result').attr("value",result);
			     }
			     });
		}
    
     return false;
     });
	
	var add_question_form = $('#add_question_form_id');
	add_question_form.submit(function () {
		var sub_name = $('#sub_name').val();
		var getUrl = window.location;
		var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
		alert(baseUrl);
//		if(sub_name.trim().length==0){
//			 $('#error_message').css('display', 'block');
//		 		$('#success_message').css('display', 'none');
//		     	$('#error_message').text('please provide subject name');
//			return false;
//		}else{
			 $.ajax({
			     type: add_question_form.attr('method'),
			     url: baseUrl+'/AddQuestionController',
			     data: add_question_form.serialize(),
			     success: function (data) {
			    	 console.log(data);
			     if(data.operationCode==1){
			    	// alert('subject successfully saved!');
			    		$('#error_message_id').css('display', 'none');
			    		$('#success_message_id').css('display', 'block');
			    	$('#success_message_id').text('question successfully saved!');
			     }else{
			    	// alert('subject does not saved!');
			    	 $('#error_message_id').css('display', 'block');
			 		$('#success_message_id').css('display', 'none');
			     	$('#error_message_id').text('question does not saved!');
			     }
			     
			    // $('#result').attr("value",result);
			     }
			     });
//		}
    
     return false;
     });
	
	
	$('#add_tutorial_detail_id').click(function(){
		getAllSubjectForAddTutorial();
	});
	
	$('#add_tutorial_btn_id').click(function(){
		$('#add_tutorial_form_id').submit();
	});
	
	
	var add_tutorial_form = $('#add_tutorial_form_id');
	add_tutorial_form.submit(function () {
		var sub_name = $('#sub_name').val();
		var getUrl = window.location;
		var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
		alert(baseUrl);
//		if(sub_name.trim().length==0){
//			 $('#error_message').css('display', 'block');
//		 		$('#success_message').css('display', 'none');
//		     	$('#error_message').text('please provide subject name');
//			return false;
//		}else{
			 $.ajax({
			     type: 'post',
			     url: baseUrl+'/AddTutorialController',
			     data: add_tutorial_form.serialize(),
			     success: function (data) {
			    	 console.log(data);
			     if(data.operationCode==1){
			    	 alert('Tutorial successfully saved!');
//			    		$('#error_message_id').css('display', 'none');
//			    		$('#success_message_id').css('display', 'block');
//			    	$('#success_message_id').text('question successfully saved!');
			     }else{
			    	 alert('Tutorial does not saved!');
//			    	 $('#error_message_id').css('display', 'block');
//			 		$('#success_message_id').css('display', 'none');
//			     	$('#error_message_id').text('question does not saved!');
			     }
			     
			    // $('#result').attr("value",result);
			     }
			     });
//		}
    
     return false;
     });
	
});

function getAllSubjectForAddTutorial(){
	var getUrl = window.location;
	var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
	alert(baseUrl);
	 $.ajax({
	     type: 'get',
	     url: baseUrl+'/GetAllSubjectController',
	     success: function (data) {
	     if(data.operationCode==1){
	    	 $('#sub_option_id').empty();
	    	 $.each(data.data["UserList"], function(key, value){
	    		  //  console.log(key); // <-- source, target
	    		   // $.each(value, function(arrKey, arrValue){
	    	var html = '<option value="'+value.sub_id+'">'+value.sub_name.toUpperCase();+'</option>';
	    	$('#sub_option_id').append(html);
	    		        console.log(value.sub_id+' : '+value.sub_name); // <-- element1, element2 etc etc
	    		    //});
	    		});
	    	 console.log(data);
	    	// alert(data);
	    //	$('#success_message').text('subject successfully saved!');
	     }else{
	    	 
	     }
	     
	    // $('#result').attr("value",result);
	     }
	     });
}

function hideAddSubjectModalMessage(){
	$('#error_message').hide();
	$('#success_message').hide();
}

function getAllSubject(){
	var getUrl = window.location;
	var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
	 $.ajax({
	     type: 'get',
	     url: "http://localhost:8080/tutorials/subjects/",
	     success: function (data) {
	     if(data.operationCode==1){
	    	 $('#subject_list_tbl_body').empty();
	    	 $.each(data.data["UserList"], function(key, value){
	    		  //  console.log(key); // <-- source, target
	    		   // $.each(value, function(arrKey, arrValue){
	    	var html = '<tr>'
	    		+'<td>'+value.sub_name+'</td>'
                +'<td><button class="btn btn-danger" onclick="deleteSubject('+value.sub_id+')"><i class="fa fa-remove" ></i></button></td>'
                +'<td><a href="#" class="btn btn-default" onclick="viewSubject('+value.sub_id+', \''+value.sub_name+'\')" ><i class="fa fa-eye"></i> View</a></td>'
              +'</tr>';
	    	$('#subject_list_tbl_body').append(html);
	    		        console.log(value.sub_id+' : '+value.sub_name); // <-- element1, element2 etc etc
	    		    //});
	    		});
	    	 console.log(data);
	    	// alert(data);
	    	$('#success_message').text('subject successfully saved!');
	     }else{
	    	 
	     }
	     
	    // $('#result').attr("value",result);
	     }
	     });
}


function deleteSubject(sub_id){
	alert(sub_id);
}

function viewSubject(sub_id,sub_name){
	window.location.replace(encodeURI('./question-list.jsp?sub_id='+sub_id+'&sub_name='+sub_name));
	//alert(sub_id);
}

function viewQuestionList(){
	var getUrl = window.location;
	var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
	var sub_id = getUrlParameter('sub_id');
	var sub_name = getUrlParameter('sub_name');
	//if(sub_id!=null && sub_name!=null){
		 $.ajax({
		     type: 'get',
		     url: baseUrl+'/GetAllQuestionController?sub_id='+sub_id,
		     success: function (data) {
		     if(data.operationCode==1){
			    	 $('#question_list_tbody').empty();
			    	 $.each(data.data["list"], function(key, value){
			    		 var answer = '';
			    		 if('option_a'==value.answer){
			    			 answer = value.option_a;
			    		 }else if('option_b'==value.answer){
			    			 answer = value.option_b;
			    		 }else if('option_c'==value.answer){
			    			 answer = value.option_c;
			    		 }else if('option_d'==value.answer){
			    			 answer = value.option_d;
			    		 }
				    	var html = '<tr>'
			                  +'<td>'
			                  +'<label>'+value.description+'</label>'
			                  +'<ol type="A">'
			                  +'<li>'+value.option_a+'</li>'
			                  +'<li>'+value.option_b+'</li>'
			                  +'<li>'+value.option_c+'</li>'
			                  +'<li>'+value.option_d+'</li>'
			                  +'</ol>'
			                  +'<span class="text-success"> Answer : '+answer+'</span>'
			                  +'</td>'
			                  +'<td>'
			                  +'<div class="btn-group">'
			                  +'<button class="btn btn-danger"><i class="fa fa-remove"></i> Delete</button>'
			                  +'</div>'
			                  +'</td>'
			                  +'</tr>';
				    	$('#question_list_tbody').append(html);
	    		       
			    		});
		    	 console.log(data.data);
		    //	$('#success_message').text('subject successfully saved!');
		     }else{
		    	
		    	 console.log(data);
		     }
		     $('#subject_name_div').empty();
	    	 $('#subject_name_div').text(sub_name);
		     $('#add_new_question_anchor_id').attr("href", encodeURI(baseUrl+'/jsp/admin/new-question.jsp?sub_id='+sub_id+'&sub_name='+sub_name));
		    // $('#result').attr("value",result);
		     }
		     });
//	}
	
	//alert(sub_id);
}

var getUrlParameter = function getUrlParameter(sParam) {
    var sPageURL = decodeURIComponent(window.location.search.substring(1)),
        sURLVariables = sPageURL.split('&'),
        sParameterName,
        i;

    for (i = 0; i < sURLVariables.length; i++) {
        sParameterName = sURLVariables[i].split('=');

        if (sParameterName[0] === sParam) {
            return sParameterName[1] === undefined ? true : sParameterName[1];
        }
    }
};


function setUpAddNewQuestionPage(){
	//var getUrl = window.location;
	//var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
	var sub_id = getUrlParameter('sub_id');
	var sub_name = getUrlParameter('sub_name');
	$('#error_message_id').css('display','none');
	$('#success_message_id').css('display','none');
	$('#sub_name_id').html('Subject Name : '+sub_name);
	$('#sub_id').val(sub_id);
	
}