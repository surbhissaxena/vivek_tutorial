$(document).ready(function(){
	var count = $('.questions').length;
	$(document).on('click','.next',function(){
		last=parseInt($(this).attr('id'));     
		nex=last+1;
		
		$("#np").text(nex);
		$('#question'+last).addClass('hide');
		$('#question'+nex).removeClass('hide');	
	});
	$(document).on('click','.previous',function(){
		last=parseInt($(this).attr('id'));
		pre=last-1;
		$("#np").text(pre);
		$('#question'+last).addClass('hide');
		$('#question'+pre).removeClass('hide');
	});
});