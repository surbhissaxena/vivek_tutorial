$(document).ready(function(){
	
	$('#reg_newuser_btn').click(function(){
		 $('#register_user').submit();
	});
	
	var register_form = $('#register_user');
	register_form.submit(function () {
			var getUrl = window.location;
			var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
			 $.ajax({
			     type:'post',
			     url: baseUrl+'/registeruser',
			     data: register_form.serialize(),
			     success: function (data) {
			    	 console.log(data);
			     if(data.operationCode==1){
			    	 alert('Successfully Submitted !');
			     }else{
			    	 alert('Not Submitted Something Went Wrong !');
			     }
			     }
			     });
    return false;
    });
	
	
//	var register_user = $('#register_user');
//	register_user.submit(function(){
//	//var getUrl = window.location;
//	//var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
//	$.ajax({
//		type:'post',
//		url:'http://localhost:8080/tutorial/registeruser',
//		data: register_user.serialize(),
//		 success: function (data) {
//			 console.log(data);
//			 if(data.operationCode == 1){
//				 alert('Successfully Submitted !');
//			 }
//			 else if(data.operationCode == 0){
//				 alert('Not Submitted Something Went Wrong !');
//			 }
//		 }
//	});
//	return false;
//	});
	
	$('.subj_id').click(function(){
		var s = $(this).attr('subject-id');
		alert(s);
	});
	$(window).resize(function(){
		var wt = window.innerWidth;
		if (wt < 768 ) {
			$('.side-list').show();
		}
		else{
			$('.side-list').hide();
			$('.sidebar_tutorial').show();

		}
	});
	$('.side-list').click(function(){
	    $('.sidebar_tutorial').toggle();
	});
	$('#exampleConfirmPassword').on('keyup',function(){
		checkPass();
	});
	$('#exampleInputPassword1').on('keyup',function(){
		checkPass();
	});
/*	var checkPass = () =>{
		var password = $('#exampleInputPassword1').val();
		var confirmPass = $('#exampleConfirmPassword').val();
		if (password !== confirmPass && password.length !== confirmPass.length) {
			$('#confirm_pass').html('<i class="fa fa-close" aria-hidden="true"></i> Password not matched');
		}
		else{
			$('#confirm_pass').html('<i class="fa fa-check" aria-hidden="true"></i> Matched');
		}
	}*/
	getAllSubject();
	function getAllSubject(){
		var getUrl = window.location;
		var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
		 $.ajax({
		     type: 'get',
		     url: "http://localhost:8080/tutorials/subjects/",
		     success: function (data) {
		     if(data.operationCode==1){
		    	 $('#subject_list_tbl_body').empty();
		    	 $.each(data.data["UserList"], function(key, value){
		    	var html = ' <div class="col-lg-3 col-md-4 col-sm-6 portfolio-item"><div class="card h-100"><a onclick="checkStatus('+value.sub_id+')" subject-id="'+value.sub_id+'">'+value.sub_name+'</a></div></div>'
		    		$('#subject_list_tu_body').append(html);
    		         
		    		      
		    		});
		    	 console.log(data);
		   
		    	$('#success_message').text('subject successfully saved!');
		     }else{
		    	 
		     }
		     
		     }
		     });
		}
});
function checkStatus(id){
	$('#subject_id').val(id);
	createCookie('SubjectId',id,1);
	readCookie('userId');
	var userId = readCookie('userId');
	console.log('userId : '+userId +'SubjectId : '+id);
	
	var verification = {
		  "async": true,
		  "crossDomain": true,
		  "url": "http://localhost:8080/tutorials/result/get/"+userId+"/"+id,
		  "method": "GET",
		  "headers": {
		    "Cache-Control": "no-cache",
		    "Postman-Token": "dd2eac1d-ab7e-ad62-53cf-f9a462b4bc08"
		  }
		}
		var getUrl = window.location;
		var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
		$.ajax(verification).done(function (response) {
			 console.log(response);
			if(response.operationCode == 1){
				$.each(response.data["resultList"], function(key, value){
				  console.log(response);
				 
					  if(value.is_qualified == true){
						  window.location.replace(baseUrl+'/jsp/tutorial-page.jsp');
					  }
					  else if(value.is_qualified == false){
						  $('#preModal').modal('show');
						  $('#test_page_url').attr('href','test-page.jsp?sub_id='+id);
					  }  
				});
			}else if(response.operationCode == 0){
				$('#preModal').modal('show');
				$('#test_page_url').attr('href','test-page.jsp?sub_id='+id);
			}
			
			else{
				alert('Record Not Found');
				  
			}
		}); 
		
		
}
var getUrlParameter = function getUrlParameter(sParam) {
    var sPageURL = decodeURIComponent(window.location.search.substring(1)),
        sURLVariables = sPageURL.split('&'),
        sParameterName,
        i;

    for (i = 0; i < sURLVariables.length; i++) {
        sParameterName = sURLVariables[i].split('=');

        if (sParameterName[0] === sParam) {
            return sParameterName[1] === undefined ? true : sParameterName[1];
        }
    }
};	
//TEst-page script
function testPageData(){
	var testSubId = getUrlParameter('sub_id');
	console.log('testSubId : '+testSubId);
	$("#subject_id").val(testSubId);
	var userName = readCookie('firstName');
	console.log(userName);
	$('#user_name').html(userName);
	 

	 var questionsList = {
	   "async": true,
	   "crossDomain": true,
	   "url": "http://localhost:8080/tutorials/question/get/"+testSubId,
	   "method": "GET",
	   "headers": {
	     "Cache-Control": "no-cache",
	     "Postman-Token": "ad01d7f2-27ab-c56c-e159-5e8730266247"
	   }
	 }
	 $.ajax(questionsList).done(function (data) {
	   console.log(data);
	   var count = 1;
	   $.each(data.data["list"], function(key, value){
	 	var html = '<div id="question'+count+'" class="quesTest"><div class="questions"><div class="well well-sm"><label>Q . '+count+') '+value.description+'</label></div></div>'
	 	+'<div class="radio">'
	     +'<label><input type="radio" name="optradio_'+value.question_id+'" value="option_a">'+value.option_a+'</label>'
	     +'</div>'
	     +'<div class="radio">'
	     +'<label><input type="radio" name="optradio_'+value.question_id+'" value="option_b">'+value.option_b+'</label>'
	     +'</div>'
	     +'<div class="radio">'
	     +'<label><input type="radio" name="optradio_'+value.question_id+'" value="option_c">'+value.option_c+'</label>'
	     +'</div>'
	     +'<div class="radio">'
	     +'<label><input type="radio" name="optradio_'+value.question_id+'" value="option_d">'+value.option_d+'</label>'
	     +'</div>'
	     +'<div class="btn-group">'
	     +'<button id="'+count+'" class="previous btn btn-default btn-sm" type="button">Previous</button>'
	     +'<button id="'+count+'" onclick="getAnswer('+value.question_id+')" class="next btn btn-primary btn-sm" type="button">Next</button>'                             
	  	+'</div></div>';
	 	
	 	$('#all_questions').append(html);
	 	count++;    
	 	});
	   $('.quesTest').addClass('hide');
		$('#question'+1).removeClass('hide');
		$('#question1 .previous').addClass('hide');
		$('#question'+(count-1)+' .next').addClass('hide');
		console.log('last count : '+(count-1));
	 });
}
function tutorialPage(){
	var uid = readCookie('userId');
	var sid = readCookie('SubjectId');
	var tutorialpage = {
			  "async": true,
			  "crossDomain": true,
			  "url": "http://localhost:8080/tutorials/tutorial/get/"+uid+"/"+sid,
			  "method": "GET",
			  "headers": {
			    "Cache-Control": "no-cache",
			    "Postman-Token": "9d8f5c20-53a9-590b-d872-6ad7aa35a2e4"
			  }
			}

	$.ajax(tutorialpage).done(function (data) {
	   console.log(data);
	   if(data.operationCode == 1){
	   $.each(data.data["list"], function(key, value){
		  
		 	var html = '<a href="#'+value.heading+'" class="tuto-headings"><h5 class="text-left" >'+value.heading+'</h5></a>';
		 	var html1 = '<section id="'+value.heading+'"><i><h4 class="font-weight-bold">'+value.heading+'</h4></i>'
		 				+'<p>'+value.description+'</p></section>';
		 	$('#sidebar_tutorial').append(html);
		 	$('#tutorial_body').append(html1);
		 		console.log("value.heading : "+value.heading);
		 
		 	});
	   }
	   else if(data.operationCode == 0){
		   alert('No Record Found');
	   }
	   });
}
function getAnswer(qid){
	var uidTest = readCookie('userId');
	var sidTest = readCookie('SubjectId');
	var answer = $("input[name=optradio_"+qid+"]:checked").val();
	if(answer){
		var questionAnswer = {
		  "async": true,
		  "crossDomain": true,
		  "url": "http://localhost:8080/tutorials/answersheet/update/answer/",
		  "method": "POST",
		  "headers": {
		    "Content-Type": "application/json",
		    "Cache-Control": "no-cache",
		    "Postman-Token": "c77536c0-9281-0d42-52ca-7d35ed3dcce8"
		  },
		  "processData": false,
		  "data": "{\n\t\n \"questionId\":\""+qid+"\",\n\t\"subId\":\""+sidTest+"\",\n\t\"userId\":\""+uidTest+"\",\n\t\"answer\":\""+answer+"\"\t\n}"
		}

		$.ajax(questionAnswer).done(function (ans) {
		  console.log(ans);
		});
	}
}
function showTestResult(){
	var uidResult = readCookie('userId');
	var sidResult = readCookie('SubjectId');
	var getResult = {
	  "async": true,
	  "crossDomain": true,
	  "url": "http://localhost:8080/tutorials/result/get/"+uidResult+"/"+sidResult,
	  "method": "GET",
	  "headers": {
	    "Cache-Control": "no-cache",
	    "Postman-Token": "9bb1507a-e1c1-5908-9cf9-c9aae50f478d"
	  }
	}
	var getUrl = window.location;
	var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
	$.ajax(getResult).done(function (response) {
	  console.log(response);
	  console.log('response.is_qualified : '+response.is_qualified);
	  if(response.is_qualified == 1){
		  alert('You have passed the exam !');
		  window.location.replace(baseUrl+'/jsp/tutorial-page.jsp');
	  }
	  else if(response.is_qualified == 0){
		  alert('Sorry You have failed !');
		  window.location.replace(baseUrl+'/jsp/tutorial-sub-page.jsp');
	  }
	});
}

function calculateResult(){
	var uidResult = readCookie('userId');
	var resultSubId = getUrlParameter('sub_id');
	
	var calResult = {
	  "async": true,
	  "crossDomain": true,
	  "url": "http://localhost:8080/tutorials/result/calculate/"+uidResult+"/"+resultSubId,
	  "method": "GET",
	  "headers": {
	    "Cache-Control": "no-cache",
	    "Postman-Token": "f5dcae74-5a1e-9968-3325-64a9658de0c6"
	  }
	}

	$.ajax(calResult).done(function (response) {
	  console.log(response);
	  
	  if(response.operationCode == 1){
		  var viewResult = {
				  "async": true,
				  "crossDomain": true,
				  "url": "http://localhost:8080/tutorials/result/get/"+uidResult+"/"+resultSubId,
				  "method": "GET",
				  "headers": {
				    "Cache-Control": "no-cache",
				    "Postman-Token": "767b9e56-a2dc-c608-5632-4d246099c9aa"
				  }
				}
		  		var getUrl = window.location;
				var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
				$.ajax(viewResult).done(function (res) {
				  console.log(res);
				  if(res.operationCode == 1){
					  $.each(res.data["resultList"], function(key, value){
						  if(value.is_qualified == true){
							  alert('You Have Passed the exam');
							 
							  window.location.replace(baseUrl+'/jsp/tutorial-page.jsp');
						  }
						  else if(value.is_qualified == false){
							  alert('You Have Failed in exam');
							
							  window.location.replace(baseUrl+'/jsp/tutorial-sub-page.jsp');
						  } 
					  });
				  }else{
					  
				  }
				});
	  }else if(response.operationCode == 0){
		  
	  }
	  
	});
	
}
function regisrationData(){
	
	
	
}
